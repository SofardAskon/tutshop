<div class="col-6">

    <div class="form-group">
        <label>Названия</label>
        <input type="text" class="form-control form-control-border" name="name" value="{{ $size->name ?? '' }}"
            placeholder="Названия">
    </div>
</div>

<button type="submit" class="btn btn-primary">Сохранить</button>
