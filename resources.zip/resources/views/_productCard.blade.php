@foreach ($products as $product)
    <article class="products-items__item item-product">
        <a href="{{ route('product', $product->id) }}" class="item-product__image">
            @foreach ($product->downloads as $index => $downloadItem)
                @if ($index == 0)
                    <img class="item-product__img item-product__img_first" src="{{ asset('storage') . '/' . $downloadItem->path }}" alt="" style="object-fit:cover;">
                @endif
            @endforeach
            @foreach ($product->downloads as $index => $downloadItem)
                @if ($index == 0)
                    <img class="item-product__img item-product__img_first" src="{{ asset('storage') . '/' . $downloadItem->path }}" alt="" style="object-fit:cover;">
                @endif
            @endforeach
            @if ($product->old_price)
                @php
                    $discount = 100 - ($product->price / $product->old_price) * 100;
                @endphp
                <span class="item-product__sale">{{ round($discount) }}%</span>
            @endif
            {{-- <button class="item-product__favotite _icon-favorite"></button> --}}
        </a>
        <div class="item-product__content">
            {{-- <div class="item-product__subtitle">Куплено более 2100</div> --}}
            <div class="item-product__price price-product">
                <div class="price-product__current">{{ $product->price }} сум</div>
                @if ($product->old_price)
                    <div class="price-product__old">{{ $product->old_price }} сум</div>
                @endif
            </div>
            <a href="{{ route('product', $product->id) }}" class="item-product__title">{{ $product->name }}</a>
            <div class="item-product__colors">
                {{-- <a href="" class="colors-item active"><span style="background-color: #000;"></span></a> --}}
                @foreach ($product->colors as $color)
                    <a href="#" class="colors-item"><span style="background-color: {{ $color->hex_code }};"></span></a>
                @endforeach
            </div>
            <div class="item-product__buttons">
                {{-- <button class="item-product__card-button _icon-card-product"></button> --}}
                <a href="{{ route('product', $product->id) }}" class="button">{{ trans('common.details') }}</a>
            </div>
        </div>
    </article>
@endforeach
@if (!sizeof($products))
    <div class="product-not-found">
        <h2>{{ trans('common.nothing_found') }}</h2>
        <a href="{{ route('shop') }}">{{ trans('common.see_all') }}</a>
    </div>
@endif
